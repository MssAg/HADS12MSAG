﻿Imports Lab_2.accesodatosSQL
Imports System.Data.SqlClient
Imports System.Xml
Imports System.IO

Public Class ImportarTarea
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim result As String
        result = conectar()
        Label2.Text = ""
        If Session.Contents("Usuario") = "" Or Session.Contents("TipoUsuario") = "A" Then
            Server.Transfer("Inicio.aspx", True)
        End If
        If (Page.IsPostBack) Then
        Else
            DropDownList1.DataBind()
        End If

        If (File.Exists(Server.MapPath("App_Data/" & DropDownList1.SelectedValue & ".xml"))) Then
            Xml1.DocumentSource = Server.MapPath("App_Data/" & DropDownList1.SelectedValue & ".xml")
            Xml1.TransformSource = Server.MapPath("App_Data/XSLTFile.xsl")
        Else
            Label2.Text = "No existe un archivo XML para la asignatura seleccionada"
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If (File.Exists(Server.MapPath("App_Data/" & DropDownList1.SelectedValue & ".xml"))) Then
            Dim xmldoc = New XmlDocument()
            xmldoc.Load(Server.MapPath("App_Data/" & DropDownList1.SelectedValue & ".xml"))
            Dim tareas As XmlNodeList

            Dim da = tareasGenericas()
            Dim ds As New DataSet()
            da.Fill(ds, "TareasGenericas")
            Dim dt = ds.Tables("TareasGenericas")
            tareas = xmldoc.GetElementsByTagName("tarea")
            Dim nuevaFila As DataRow
            Dim i As Integer
            For i = 0 To tareas.Count - 1
                nuevaFila = dt.NewRow()
                nuevaFila.Item("Codigo") = tareas(i).ChildNodes(0).ChildNodes(0).Value
                nuevaFila.Item("Descripcion") = tareas(i).ChildNodes(1).ChildNodes(0).Value
                nuevaFila.Item("HEstimadas") = tareas(i).ChildNodes(2).ChildNodes(0).Value
                nuevaFila.Item("CodAsig") = DropDownList1.SelectedValue
                If tareas(i).ChildNodes(3).ChildNodes(0).Value = "true" Then
                    nuevaFila.Item("Explotacion") = 1
                Else
                    nuevaFila.Item("Explotacion") = 0
                End If
                nuevaFila.Item("TipoTarea") = tareas(i).ChildNodes(4).ChildNodes(0).Value
                dt.Rows.Add(nuevaFila)
            Next
            Dim builder As New SqlCommandBuilder(da)
            Try
                da.Update(ds, "TareasGenericas")
                Label2.Text = "Tareas Actualizadas"
            Catch ex As Exception
                Label2.Text = "Tareas ya existentes"
            End Try

        Else
            Label2.Text = "No existe un archivo XML para la asignatura seleccionada"
        End If
    End Sub

End Class