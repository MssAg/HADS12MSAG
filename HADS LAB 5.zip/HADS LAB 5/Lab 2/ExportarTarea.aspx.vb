﻿Imports System.Xml
Imports Lab_2.accesodatosSQL
Imports System.Data.SqlClient
Public Class ExportarTarea
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim result As String
        result = conectar()
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Dim writer As New XmlTextWriter(Server.MapPath("App_Data/ISO.xml"), System.Text.Encoding.UTF8)
            writer.WriteStartDocument(True)
            writer.Formatting = Formatting.Indented
            writer.Indentation = 2
            writer.WriteStartElement("tareas")
            Dim da = tareasGenericasAsig(DropDownList1.SelectedValue)
            Dim ds As New DataSet()
            da.Fill(ds, "Tareas")
            Dim dt = ds.Tables("Tareas")
            Dim i As Integer
            Dim codigo As String = ""
            Dim descripcion As String = ""
            Dim hestimadas As String = ""
            Dim exp As String = ""
            Dim tipoTarea As String = ""
            For i = 0 To dt.Rows.Count - 1
                codigo = dt.Rows(i).Item(0)
                descripcion = dt.Rows(i).Item(1)
                hestimadas = dt.Rows(i).Item(3)
                exp = dt.Rows(i).Item(4)
                tipoTarea = dt.Rows(i).Item(5)
            Next
            createNode(codigo, descripcion, hestimadas, exp, tipoTarea, writer)
            writer.WriteEndElement()
            writer.WriteEndDocument()
            writer.Close()
        Catch ex As Exception
            Label2.Text = ex.Message
        End Try
        Label2.Text = "Tarea Exportada"
    End Sub
    Private Sub createNode(ByVal cod As String, ByVal desc As String, ByVal horasE As String, ByVal exp As String, ByVal tipo As String, ByVal writer As XmlTextWriter)
        writer.WriteStartElement("tarea")
        writer.WriteStartElement("codigo")
        writer.WriteString(cod)
        writer.WriteEndElement()
        writer.WriteStartElement("descripcion")
        writer.WriteString(desc)
        writer.WriteEndElement()
        writer.WriteStartElement("hestimadas")
        writer.WriteString(horasE)
        writer.WriteEndElement()
        writer.WriteStartElement("explotacion")
        writer.WriteString(exp)
        writer.WriteEndElement()
        writer.WriteStartElement("tipotarea")
        writer.WriteString(tipo)
        writer.WriteEndElement()
        writer.WriteEndElement()
    End Sub
End Class